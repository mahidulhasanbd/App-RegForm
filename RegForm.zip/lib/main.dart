import 'package:flutter/material.dart';
import 'package:flutterapp/regformapp/generatediphone14pro1widget/GeneratedIPhone14Pro1Widget.dart';
import 'package:flutterapp/regformapp/generatedsection1widget/GeneratedSection1Widget.dart';
import 'package:flutterapp/regformapp/generatedtextwidget/GeneratedTextWidget.dart';

void main() {
  runApp(RegFormApp());
}

class RegFormApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/GeneratedIPhone14Pro1Widget',
      routes: {
        '/GeneratedIPhone14Pro1Widget': (context) =>
            GeneratedIPhone14Pro1Widget(),
        '/GeneratedSection1Widget': (context) => GeneratedSection1Widget(),
        '/GeneratedTextWidget': (context) => GeneratedTextWidget(),
      },
    );
  }
}
